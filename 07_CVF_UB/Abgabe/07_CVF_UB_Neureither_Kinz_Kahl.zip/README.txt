No solution to 7.2. 
Solution to 7.1c in the .ipynb.
